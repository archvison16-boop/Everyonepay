EveryonePay - Working App Prototype (PWA)
==========================================

WHAT THIS IS
------------
A fully connected, installable demo of all 32 EveryonePay screens
(light + dark mode), with working navigation between screens, a
PIN keypad, theme toggle, and a "Screens" menu to jump anywhere.

This is a UI/UX prototype with mock data — no real bank accounts,
UPI, or money movement happen. Building real payment functionality
requires NPCI/UPI certification and a banking/PPI license.

HOW TO INSTALL ON YOUR PHONE (as an app icon)
----------------------------------------------
A PWA needs to be served over the internet (https) for full
"Install app" support. Easiest free ways to host this folder:

1) Netlify Drop (fastest, no signup):
   - Go to https://app.netlify.com/drop on your computer
   - Drag this whole folder onto the page
   - You'll get a live https link in seconds

2) GitHub Pages:
   - Create a new GitHub repo, upload these files
   - Settings -> Pages -> deploy from main branch
   - You'll get a link like https://username.github.io/repo

Once you have the https link:
- Android (Chrome): open the link -> menu (⋮) -> "Install app" /
  "Add to Home screen"
- iPhone (Safari): open the link -> Share button -> "Add to Home
  Screen"

The app icon will appear on your home screen and opens full-screen,
like a real app. It also works offline after the first load.

LOCAL PREVIEW (on a computer, right now)
-----------------------------------------
Double-click index.html to open it in any browser — navigation,
theme toggle, and the screen menu all work directly from the file.
(Full "Install app" prompt only appears once hosted on https.)

FILES
-----
index.html      - the app shell (all 32 screens embedded)
app.js          - navigation logic, PIN keypad, theme toggle
theme.css       - light + dark theme styles
manifest.json   - PWA install config
sw.js           - offline caching (service worker)
icon-*.png      - app icons

ABOUT NATIVE APK / iOS IPA
---------------------------
A real installable .apk (Android) or .ipa (iOS) requires native
build tooling (Android SDK/Gradle, or a Mac + Xcode + Apple
Developer account for iOS) which isn't available in this
environment. Once hosted, this same PWA can be wrapped into a real
APK later using a tool like Bubblewrap (Google's official PWA-to-
APK tool) or Capacitor, if you want a Play Store listing.
