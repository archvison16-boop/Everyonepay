(function () {
  var START = "01_splash";
  var HOME = "05_home";
  var stack = [];
  var current = null;

  function screensFor(id, theme) {
    return document.querySelectorAll(
      '.screen-page[data-screen="' + id + '"]'
    );
  }

  function render() {
    var theme = document.body.getAttribute("data-theme");
    document.querySelectorAll(".screen-page").forEach(function (el) {
      var match =
        el.getAttribute("data-screen") === current &&
        el.getAttribute("data-theme-page") === theme;
      el.classList.toggle("active", match);
    });
    window.scrollTo(0, 0);
  }

  function goto(id, opts) {
    opts = opts || {};
    if (!id) return;
    if (current && !opts.replace) stack.push(current);
    current = id;
    render();
  }

  function goBack() {
    if (stack.length > 0) {
      current = stack.pop();
    } else {
      current = HOME;
    }
    render();
  }

  function setTheme(t) {
    document.body.setAttribute("data-theme", t);
    document.getElementById("theme-toggle").textContent =
      t === "light" ? "🌙 Dark" : "☀️ Light";
    render();
  }

  // Delegate clicks
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-go]");
    if (!el) return;
    var target = el.getAttribute("data-go");
    if (target === "__back__") {
      goBack();
    } else {
      goto(target);
    }
  });

  // Theme toggle
  document.getElementById("theme-toggle").addEventListener("click", function () {
    var cur = document.body.getAttribute("data-theme");
    setTheme(cur === "light" ? "dark" : "light");
  });

  // Drawer
  var drawer = document.getElementById("drawer");
  var overlay = document.getElementById("drawer-overlay");
  function openDrawer() {
    drawer.classList.add("open");
    overlay.classList.add("open");
  }
  function closeDrawer() {
    drawer.classList.remove("open");
    overlay.classList.remove("open");
  }
  document.getElementById("menu-toggle").addEventListener("click", openDrawer);
  overlay.addEventListener("click", closeDrawer);
  drawer.addEventListener("click", function (e) {
    var item = e.target.closest(".drawer-item");
    if (item) {
      goto(item.getAttribute("data-go"));
      closeDrawer();
    }
  });

  // Fake clock
  function tickClock() {
    var d = new Date();
    var h = d.getHours() % 12 || 12;
    var m = d.getMinutes().toString().padStart(2, "0");
    document.getElementById("clock").textContent = h + ":" + m;
  }
  tickClock();
  setInterval(tickClock, 30000);

  // Boot
  current = START;
  render();

  // Auto-advance splash -> login after 1.6s
  setTimeout(function () {
    if (current === START) goto("02_login", { replace: true });
  }, 1600);

  // PIN keypad: tapping digits fills dots, auto-advances after 4 taps
  var pinCount = 0;
  document.addEventListener("click", function (e) {
    var key = e.target.closest("[data-pin-key]");
    if (!key) return;
    var activeScreen = document.querySelector(".screen-page.active");
    if (!activeScreen || !activeScreen.contains(key)) return;
    var dots = activeScreen.querySelectorAll(
      'div[style*="border-radius:50%"][style*="14px"]'
    );
    pinCount++;
    dots.forEach(function (d, i) {
      if (i < pinCount) {
        d.style.background = "#D9622E";
        d.style.border = "none";
      }
    });
    if (pinCount >= 4) {
      var target = key.getAttribute("data-pin-target");
      setTimeout(function () {
        pinCount = 0;
        goto(target);
      }, 350);
    }
  });

  // Face ID screen: tapping anywhere (outside passcode link) simulates success -> home
  document.addEventListener("click", function (e) {
    if (current !== "04_face_id") return;
    if (e.target.closest("[data-go]")) return; // handled above
    goto(HOME, { replace: true });
  });

  // Register service worker for offline use
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("sw.js").catch(function () {});
    });
  }
})();
